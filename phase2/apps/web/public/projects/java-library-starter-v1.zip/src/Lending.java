import java.util.List;

public final class Lending {
    static List<Library.Book> borrow(List<Library.Book> books, String id, String borrower) {
        // TODO: Validate the request and return a new list with the available book lent to the borrower.
        throw new UnsupportedOperationException("Borrow is incomplete");
    }
}

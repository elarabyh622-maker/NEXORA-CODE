#include "expenses.hpp"

std::optional<Summary> summarize(const std::vector<Expense>& /* expenses */) {
    // TODO: Accumulate totals per category and the grand total, then return the Summary.
    return std::nullopt;
}

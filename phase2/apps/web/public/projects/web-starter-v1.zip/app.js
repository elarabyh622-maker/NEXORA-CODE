const nameInput = document.querySelector("#name");
const message = document.querySelector("#message");

function showMessage() {
  const name = nameInput.value.trim();
  // اكتب هنا نص الترحيب عندما يوجد اسم، واطلب الاسم عند الفراغ.
  // غيّر message.textContent بدلًا من إضافة HTML من إدخال المستخدم.
}

document.querySelector("#show").addEventListener("click", showMessage);

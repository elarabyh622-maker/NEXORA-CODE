package main

func (s *Store) complete(id int) (Task, error) {
	// TODO: Lock the store, find the task, reject a completed task, then complete it.
	return Task{}, ErrIncomplete
}
